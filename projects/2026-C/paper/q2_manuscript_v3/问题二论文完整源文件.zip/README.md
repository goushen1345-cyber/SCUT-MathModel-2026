# 问题二独立论文章节

2026年9月11日，依据用户Q2-WRITE-055授权局部起草。正文只包含问题二，不合并前文，不改变研究阶段。主文件为`问题二的模型建立与求解.tex`，正文在`chapter.tex`；同名PDF供阅读。独立章节按1—8小节、图1—3、表1—4编号，全文整合时再统一，不在这次改写前文。

已写内容：日前信息与费用矛盾；负载/光伏分别预测；近期误差权重与准备量；决策变量、目标及设备约束；实际补救和全年启动；方案比较；全年与四个指定日结果；灵敏度和简短风险、适用范围说明。3幅图分别说明月度收益、指定日供电机制、参数对普通/紧急费用的影响。正文将补充连续误差检验压到最后一段，取样范围放脚注；完整尾部统计和分组反例保留于研究证据，不机械逐项塞入正文。

## 来源与范围

- 数学与实际运行：`../../questions/Q2/report.md`的Q2-annual-v4与Q2-validation-v5；论文证据Q2-C09—C21。
- 年度结果：`../../questions/Q2/runs/20260911-annual-validation-v1/`。主方案2—12月334天13583810.84元，计入共同1月的365天15709745.62元。四候选费用来自`annual/comparison.csv`，近期主方案来自`refinement/comparison.csv`，最终汇总在`delivery_data/summary.json`。
- 指定日三张结果表：`delivery_data/specified_table1/2/3.csv`；正文表2—4。数字由`prepare.py`同源生成，显示两位小数，研究输出完整精度未改。
- 参数敏感性：最终α来自`supplement/comparison.csv`，β=.7/.9来自`refinement/comparison.csv`，β=.8来自`validation/comparison.csv`中的`weighted-error`。没有把原等权α敏感性冒充当前方案。
- 输入扰动：`../../questions/Q2/runs/20260911-targeted-validation-v1/analysis/scenario_comparison.csv`及原protocol；仅诊断情景，未宣称独立泛化。原年度方法家族选择参考过全年资料。
- 全部19个主要来源的写作前指纹见`source_manifest.json`；图输入摘录、版本和指纹见`figures/manifest.json`。图的唯一项目登记为`../../paper_evidence/figure_registry.md`的Q2-F03—F05。

## 图表和编译

已有图为矢量PDF和300dpi PNG，完整素材在`figures/`。编译现有正文无需重新绘图或运行模型。在本目录使用XeLaTeX编译主TeX两遍即可。`build.py`适配本机已安装的MiKTeX/Poppler，编译两遍、生成PDF并将全部页面渲染至`preview/`；环境与源码指纹写入`build/record.json`。

如在仓库内复现图表，从项目根目录执行：

```powershell
& 'E:/Anaconda/python.exe' -X utf8 projects/2026-C/paper/q2_manuscript_v2/prepare.py --output projects/2026-C/tmp/自行指定的新目录
```

该程序只读已存在的结果，不训练、优化或模拟。实际已在`tmp/q2-manuscript-fig-reproduction-v1`复现3个PNG和3个PDF；对照结果见`qa.json`。使用SimSun与Matplotlib，Windows受限运行环境可能阻止本地绘图库或排版程序加载，实际调用经工具授权运行，没有修改系统安全设置。

完整源文件包包含主TeX、正文、表格片段、三图PDF/PNG、绘图输入摘录和脚本。打包后可独立编译已有论文；重新从原始研究结果生图仍需上面的项目结果路径。

## 编辑取舍与待阅事项

- 这次新增独立8页章，没有覆盖原17页合稿里的150天历史版本。将来整合时，应以当前全年章替换那一旧局部，避免重复两套问题二。
- 核心公式完整，主要文字解释动机和结果，权重没有被写成熵权或可靠率。保留1月零余量更便宜、短窗口存在反例、单日增费、48小时并非严格省钱、期末项未产生可测费用收益等必要限制。
- 正文只用完整年度与补充验证的已有事实；没有新模型、实验、模板填写、冻结、跨问或提交。
- 共8页。第4/6/7页末保留空间让整幅图在下一页完整展示，未缩字挤图；题注、单位和指定日期表均保留。AI实际检查全部渲染页，尚非人类审定。
- 用户需要审阅措辞和篇幅；全文统一符号、图表序号与全题综合评价留待后续明确授权的整合。完整论文的匿名、当届提交规范及AI使用声明尚不是本次局部章交付对象；没有生成“可直接正式提交”的结论。

问题一另更新`../../paper_evidence/问题一模型详细讲解报告.md`，保留35126.85元结果，补上0.10元时间对照来源、Q1/Q2边界差别及可用图片入口。
